import h5py, numpy as np, sys


FILE = "galacticus_for_max.hdf5"

with h5py.File(FILE, "r") as f:
    redshifts = sorted([f["Outputs"][k]["nodeData"]["redshift"][0] 
                        for k in f["Outputs"]])
print("Available redshifts:", np.round(redshifts, 3))

target_z = float(sys.argv[1]) if len(sys.argv) > 1 else 0.0

with h5py.File(FILE, "r") as f:
    snaps = {k: {d: f["Outputs"][k]["nodeData"][d][()] 
                 for d in f["Outputs"][k]["nodeData"]} 
             for k in f["Outputs"]}

snap = min(snaps.values(), key=lambda s: abs(s["redshift"][0] - target_z))
z    = snap["redshift"][0]
mask = snap["nodeIsIsolated"] == 0

host_mask = snap["nodeIsIsolated"] == 1
host_idx  = np.argmax(snap["basicMass"][host_mask])
print(f"Host: nodeIndex={snap['nodeIndex'][host_mask][host_idx]}  "
      f"M_vir={snap['basicMass'][host_mask][host_idx]:.3e} Msun  "
      f"r_s={snap['darkMatterProfileScale'][host_mask][host_idx]*1e3:.3f} kpc")

print(f"Snapshot z={z:.4f} | {mask.sum()} subhalos")

# Save table
cols = ["nodeIndex","positionOrbitalX","positionOrbitalY","positionOrbitalZ",
        "velocityOrbitalX","velocityOrbitalY","velocityOrbitalZ",
        "basicMass","satelliteBoundMass","darkMatterProfileScale",
        "satellitePericenterRadius","satelliteApocenterRadius","satelliteDistanceMinimum"]

header = "nodeIndex  x[Mpc]  y[Mpc]  z[Mpc]  vx[km/s]  vy[km/s]  vz[km/s]  " \
         "M_vir[Msun]  M_bound[Msun]  rs[Mpc]  r_peri[Mpc]  r_apo[Mpc]  r_min[Mpc]"

data = np.column_stack([snap[c][mask] for c in cols])
np.savetxt(f"subhalos_z{z:.2f}.txt", data, header=header, fmt="%15.6e")
print(f"Saved subhalos_z{z:.2f}.txt")
